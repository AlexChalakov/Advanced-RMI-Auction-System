public class NewUserInfo implements java.io.Serializable {
    int userID;
    byte privateKey[];
    byte publicKey[];
}