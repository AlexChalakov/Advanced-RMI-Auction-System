public interface ReplicaComms extends Auction {
    public void updateReplica();
}
