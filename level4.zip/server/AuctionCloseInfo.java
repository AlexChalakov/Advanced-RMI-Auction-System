public class AuctionCloseInfo implements java.io.Serializable {
    String winningEmail;
    int winningPrice;
}